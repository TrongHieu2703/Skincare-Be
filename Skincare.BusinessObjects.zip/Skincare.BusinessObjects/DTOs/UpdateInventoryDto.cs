﻿using System;

namespace Skincare.BusinessObjects.DTOs
{
    public class UpdateInventoryDto
    {
        public int? Quantity { get; set; }   
    }
}
