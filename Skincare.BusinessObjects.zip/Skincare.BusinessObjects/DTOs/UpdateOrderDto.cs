﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Skincare.BusinessObjects.DTOs
{
    public class UpdateOrderDto
    {
        public int? VoucherId { get; set; }
        public bool? IsPrepaid { get; set; }
        public string Status { get; set; }
        public decimal? TotalPrice { get; set; }
        public decimal? DiscountPrice { get; set; }
        public decimal? TotalAmount { get; set; }

        public List<OrderItemDto> OrderItems { get; set; } = new List<OrderItemDto>();
        public List<TransactionDto> Transactions { get; set; } = new List<TransactionDto>();
    }


}
