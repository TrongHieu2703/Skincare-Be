﻿using System;

namespace Skincare.BusinessObjects.DTOs
{
    public class UpdateReviewDto
    {
        public int? Rating { get; set; }
        public string Comment { get; set; }
    }
}
