//namespace Skincare.BusinessObjects.DTOs
//{
//    public class PaymentStatus
//    {
//        public int Id { get; set; }
//        public string Status { get; set; }
//    }
//}
