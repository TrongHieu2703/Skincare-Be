﻿//using Skincare.BusinessObjects.Entities;
//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace Skincare.Repositories.Interfaces
//{
//    public interface IPaymentRepository
//    {
//        Task<Payment> ProcessPaymentAsync(Payment payment);
//        Task<Payment> GetPaymentByIdAsync(int id);
//    }

//}
